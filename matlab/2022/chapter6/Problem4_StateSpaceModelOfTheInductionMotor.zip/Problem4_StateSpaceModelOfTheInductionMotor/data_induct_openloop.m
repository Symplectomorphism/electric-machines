%MOTOR PARAMETERS
clear 
close all
clc

M = 0.0117; %Henrys
Rr = 3.9; %Ohms
Rs = 1.7; %Ohms
Lr = 0.014; %Henrys
Ls = 0.014; %Henrys
B = 0; %.00014; %.00014; %Nm/rad/sec
J = 0.00011; % kgm^2
np = 3; %pole-pairs
V = 160;
ws = 2*pi*60;
tau_L = 0.1;  % Will still start with tau_L = 15

sigma = 1 - M*M/(Lr*Ls);
% eta = Rr/Lr;
% beta = M/(sigma*Lr*Ls);
% mu = np*M/(J*Lr);
% gamma = M*M*Rr/(sigma*Lr*Lr*Ls) + Rs/(sigma*Ls);

